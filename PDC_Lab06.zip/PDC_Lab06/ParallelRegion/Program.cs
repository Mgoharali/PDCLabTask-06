﻿
using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        int degree = args.Length > 0
            ? int.Parse(args[0])
            : Environment.ProcessorCount;
        if (degree < 1)
        {
            Console.WriteLine("Degree must be at least 1.");
            return;
        }
        Console.WriteLine($"Processor count: {Environment.ProcessorCount}");
        Console.WriteLine($"Maximum degree of parallelism: {degree}");

        const int iterations = 20;
        var threadIds = new ConcurrentDictionary<int, byte>();
        var options = new ParallelOptions
        {
            MaxDegreeOfParallelism = degree
        };

        Stopwatch stopwatch = Stopwatch.StartNew();

        Parallel.For(0, iterations, options, i =>
        {
            int threadId = Thread.CurrentThread.ManagedThreadId;
            threadIds.TryAdd(threadId, 0);

            Console.WriteLine(
                $"Iteration {i}: Thread ID {threadId}");

            Thread.Sleep(100);
        });
        stopwatch.Stop();
        double elapsedMs = stopwatch.Elapsed.TotalMilliseconds;
        double predictedMs = Math.Ceiling((double)iterations / degree) * 100;
        Console.WriteLine();
        Console.WriteLine($"Distinct threads: {threadIds.Count}");
        Console.WriteLine($"Thread IDs: {string.Join(", ", threadIds.Keys.OrderBy(id => id))}");
        Console.WriteLine($"Elapsed time: {elapsedMs:F2} ms");
        Console.WriteLine($"Predicted time: {predictedMs:F2} ms");
    }
}
