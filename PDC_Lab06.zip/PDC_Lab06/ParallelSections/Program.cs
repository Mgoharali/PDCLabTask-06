﻿
using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    const int N = 5_000_000;

    static long OperationA()
    {
        long sum = 0;

        for (int i = 0; i < N; i++)
        {
            sum += i % 1000;
        }

        return sum;
    }

    static long OperationB()
    {
        long sum = 0;

        for (int i = 0; i < N; i++)
        {
            long value = i % 1000;
            sum += value * value;
        }

        return sum;
    }

    static long OperationC()
    {
        long sum = 0;

        for (int i = 0; i < N; i++)
        {
            long first = i % 1000;
            long second = (i + 1) % 1000;
            sum += first * second;
        }

        return sum;
    }

    static double MeasureSerial(Func<long> operation, out long result)
    {
        Stopwatch stopwatch = Stopwatch.StartNew();
        result = operation();
        stopwatch.Stop();

        return stopwatch.Elapsed.TotalSeconds;
    }

    static void Main(string[] args)
    {
        int degree = args.Length > 0
            ? int.Parse(args[0])
            : Environment.ProcessorCount;

        if (degree < 1)
        {
            Console.WriteLine("Degree must be at least 1.");
            return;
        }

        double timeA = MeasureSerial(OperationA, out long serialA);
        double timeB = MeasureSerial(OperationB, out long serialB);
        double timeC = MeasureSerial(OperationC, out long serialC);

        double serialTotal = timeA + timeB + timeC;

        long resultA = 0;
        long resultB = 0;
        long resultC = 0;

        int threadA = -1;
        int threadB = -1;
        int threadC = -1;

        var options = new ParallelOptions
        {
            MaxDegreeOfParallelism = degree
        };

        Stopwatch stopwatch = Stopwatch.StartNew();

        Parallel.Invoke(
            options,
            () =>
            {
                threadA = Thread.CurrentThread.ManagedThreadId;
                resultA = OperationA();
            },
            () =>
            {
                threadB = Thread.CurrentThread.ManagedThreadId;
                resultB = OperationB();
            },
            () =>
            {
                threadC = Thread.CurrentThread.ManagedThreadId;
                resultC = OperationC();
            });

        stopwatch.Stop();

        double wallTime = stopwatch.Elapsed.TotalSeconds;
        double speedup = wallTime > 0 ? serialTotal / wallTime : 0;

        bool resultsMatch =
            resultA == serialA &&
            resultB == serialB &&
            resultC == serialC;

        Console.WriteLine($"Maximum degree: {degree}");
        Console.WriteLine($"Processor count: {Environment.ProcessorCount}");

        Console.WriteLine($"Serial A: {timeA:F4} s");
        Console.WriteLine($"Serial B: {timeB:F4} s");
        Console.WriteLine($"Serial C: {timeC:F4} s");
        Console.WriteLine($"Serial total: {serialTotal:F4} s");

        Console.WriteLine($"Parallel wall time: {wallTime:F4} s");
        Console.WriteLine($"Speedup: {speedup:F2}x");

        Console.WriteLine($"Thread A: {threadA}");
        Console.WriteLine($"Thread B: {threadB}");
        Console.WriteLine($"Thread C: {threadC}");

        Console.WriteLine($"Results match: {(resultsMatch ? "YES" : "NO")}");
    }
}
