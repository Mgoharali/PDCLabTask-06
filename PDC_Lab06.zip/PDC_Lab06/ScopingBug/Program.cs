﻿
using System;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    const int N = 100_000;

    static void Main(string[] args)
    {
        string mode = args.Length > 0 ? args[0].ToLower() : "bug";
        int degree = args.Length > 1
            ? int.Parse(args[1])
            : Environment.ProcessorCount;

        if (degree < 1)
        {
            Console.WriteLine("Degree must be at least 1.");
            return;
        }

        int[] input = new int[N];
        int[] output = new int[N];

        for (int i = 0; i < N; i++)
        {
            input[i] = i;
        }

        var options = new ParallelOptions
        {
            MaxDegreeOfParallelism = degree
        };

        if (mode == "bug")
        {
            // BUG: All iterations share this temporary variable.
            int tmp = 0;

            Parallel.For(0, N, options, i =>
            {
                tmp = input[i] * 3;
                Thread.SpinWait(20);
                output[i] = tmp + 7;
            });
        }
        else if (mode == "threadlocal")
        {
            // FIX 1: Each local execution state has its own tmp.
            Parallel.For<int>(
                0,
                N,
                options,
                () => 0,
                (i, state, tmp) =>
                {
                    tmp = input[i] * 3;
                    Thread.SpinWait(20);
                    output[i] = tmp + 7;
                    return tmp;
                },
                tmp => { });
        }
        else if (mode == "local")
        {
            // FIX 2: tmp is declared inside each iteration.
            Parallel.For(0, N, options, i =>
            {
                int tmp = input[i] * 3;
                Thread.SpinWait(20);
                output[i] = tmp + 7;
            });
        }
        else
        {
            Console.WriteLine("Mode must be bug, threadlocal, or local.");
            return;
        }

        int wrong = 0;

        for (int i = 0; i < N; i++)
        {
            int expected = input[i] * 3 + 7;

            if (output[i] != expected)
            {
                wrong++;
            }
        }

        Console.WriteLine($"Mode: {mode}");
        Console.WriteLine($"Maximum degree: {degree}");
        Console.WriteLine($"Wrong elements: {wrong}");
        Console.WriteLine($"Correct: {(wrong == 0 ? "YES" : "NO")}");
        Console.WriteLine($"Processor count: {Environment.ProcessorCount}");
    }
}
