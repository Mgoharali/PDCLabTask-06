﻿
using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Threading.Tasks;

class Program
{
    const int N = 5_000_000;
    const int Passes = 20;
    static void VecAdd(int[] a, int[] b, int[] c, int n,
                       ParallelOptions options)
    {
        Parallel.ForEach(
            Partitioner.Create(0, n),
            options,
             range =>
            {
                for (int i = range.Item1; i < range.Item2; i++)
                {
                    c[i] = a[i] + b[i];
                }
            });
    }
    static void Main(string[] args)
    {
        int degree = args.Length > 0
            ? int.Parse(args[0])
            : Environment.ProcessorCount;
        if (degree < 1)
        {
            Console.WriteLine("Degree must be at least 1.");
            return;
        }
        int[] a = new int[N];
        int[] b = new int[N];
        int[] c = new int[N];
        for (int i = 0; i < N; i++)
        {
            a[i] = i;
            b[i] = 2 * i;
        }
        var options = new ParallelOptions
        {
            MaxDegreeOfParallelism = degree
        };

        // Warm-up run before measurement.
        VecAdd(a, b, c, N, options);
        Stopwatch stopwatch = Stopwatch.StartNew();
        for (int pass = 0; pass < Passes; pass++)
        {
            VecAdd(a, b, c, N, options);
        }
        stopwatch.Stop();
        bool correct = true;
        for (int i = 0; i < N; i++)
        {
            if (c[i] != 3 * i)
            {
                correct = false;
                break;
            }
        }

        Console.WriteLine($"Maximum degree: {degree}");
        Console.WriteLine($"N: {N}, passes: {Passes}");
        Console.WriteLine($"Elapsed: {stopwatch.Elapsed.TotalMilliseconds:F2} ms");
        Console.WriteLine($"Correct: {(correct ? "YES" : "NO")}");
    }
}
